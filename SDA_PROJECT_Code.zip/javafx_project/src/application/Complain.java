package application;
import java.util.ArrayList;

public class Complain {
    private int ID;
    private int passengerID;
    private String complaint;
  
    // Static list to store all complaints
    private static ArrayList<Complain> complaintsList = new ArrayList<>();

    // Constructor
    public Complain(int ID, int passengerID, String complaint) {
        this.ID = ID;
        this.passengerID = passengerID;
        this.complaint = complaint;
    }

    // Lodge a complaint
    public static void enterComplaint(int passengerID, String complaintText) {
        int complaintID = complaintsList.size() + 1; // Generate a unique complaint ID
        Complain complaint = new Complain(complaintID, passengerID, complaintText);
        complaintsList.add(complaint);
        System.out.println("Complaint ID " + complaintID + " lodged successfully for Passenger ID: " + passengerID);
    }

    // View complaints for a passenger
    public static void viewComplaints(int passengerID) {
        System.out.println("Complaints for Passenger ID: " + passengerID);
        for (Complain c : complaintsList) {
            if (c.getPassengerID() == passengerID) {
                System.out.println("Complaint ID: " + c.getID() + 
                                   ", Complaint: " + c.getComplaint());
            }
        }
    }

    // Mark a complaint as resolved
  

    // Getters and Setters
    public int getID() {
        return ID;
    }

    public int getPassengerID() {
        return passengerID;
    }

    public String getComplaint() {
        return complaint;
    }

}