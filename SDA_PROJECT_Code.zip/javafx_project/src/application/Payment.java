package application;


public class Payment {
	public static int id = 0;
    public int amountPaid;
    public int amountDue;
    public boolean status;

    // Constructor
    public Payment(int amountDue) {
        this.amountDue = amountDue;
        this.amountPaid = 0;
        this.status = false;
        id++;
        
    }

    public boolean paymentStatus(int amount) {
        if (amount <= 0) {
            System.out.println("Invalid payment amount.");
            return false;
        }

        if (amount < amountDue) {
            System.out.println("Payment below the amount. Please pay the exact amount.");
            return false;
        }

        this.amountPaid += amount;
        this.amountDue -= amount;

        // Update payment status
        if (amountDue == 0) {
            this.status = true;
            System.out.println("Payment completed successfully.");
            return true;
        } else {
            this.status = false;
            System.out.println("Amount due: $" + amountDue);
            return false;
        }
    }

    // Getters and setters...
}

  
