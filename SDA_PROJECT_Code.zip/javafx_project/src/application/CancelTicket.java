package application;

public class CancelTicket {
    private int cancelID; // Unique ID for cancellation
    private int bookingID; // ID of the booking being canceled
    private String refundStatus; // e.g., "Pending", "Refunded"
    private boolean cancellationStatus; // e.g., true if canceled, false otherwise

    // Constructor
    public CancelTicket(int cancelID, int bookingID) {
        this.cancelID = cancelID;
        this.bookingID = bookingID;
        this.refundStatus = "Pending"; // Default to "Pending"
        this.cancellationStatus = false; // Default to not canceled
    }

    // Cancel a booking
    public static void cancelBooking(int bookingID) {
        // Find the booking in the bookings list
        Booking bookingToCancel = null;
        for (Booking booking : Booking.getBookingsList()) {
            if (booking.getID() == bookingID) {
                bookingToCancel = booking;
                Booking.bookingsList.remove(booking);
                break;
            }
        }

        if (bookingToCancel == null) {
            System.out.println("Booking ID " + bookingID + " not found.");
            return;
        }

        // Generate a unique cancel I
        // Update flight seat availability
        Flight flight = bookingToCancel.getFlightDetails();
        flight.setRemainingSeats(flight.getRemainingSeats() + 1);

    
        System.out.println("Booking ID " + bookingID + " canceled successfully");
    }

    // View all cancellations
   

    // Getters and setters
    public int getCancelID() {
        return cancelID;
    }

    public int getBookingID() {
        return bookingID;
    }

    public String getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(String refundStatus) {
        this.refundStatus = refundStatus;
    }

    public boolean isCancellationStatus() {
        return cancellationStatus;
    }

    public void setCancellationStatus(boolean cancellationStatus) {
        this.cancellationStatus = cancellationStatus;
    }
}