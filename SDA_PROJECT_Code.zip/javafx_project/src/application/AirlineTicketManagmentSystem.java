package application;



import java.util.ArrayList;


public class AirlineTicketManagmentSystem {
    private ArrayList<Passenger> passengers = new ArrayList<>();
    private ArrayList<Flight> flights = new ArrayList<>();
    private Revenue revenue; // Composition with the Revenue class
    private DB_Handler db;
    // Constructor to initialize the system and revenue
    public AirlineTicketManagmentSystem() {
        this.revenue = new Revenue(); // Initialize Revenue instance
        db = new DB_Handler();
        passengers = db.get_Passengers();
    }

    // Methods to add passengers and flights
    public void createPassenger(Passenger passenger) {
        passengers.add(passenger);
        System.out.println("Passenger added: " + passenger.getID());
    }

    public void addFlight(Flight flight) {
        flights.add(flight);
        System.out.println("Flight added successfully!");
    }


    public boolean login(String userID, String Password)
    {
    	return db.login_Passenger(userID, Password);
    }
    
    public void passengerView() {
        if (passengers.size() == 0) { 
            System.out.println("No passengers are currently registered.");
        } else {
            System.out.println("List of All Passengers:");
            for (Passenger passenger : passengers) {
                System.out.println("Passenger ID: " + passenger.getID() +
                                   ", Name: " + passenger.getName() +
                                   ", Email: " + passenger.getEmail() +
                                   ", Address: " + passenger.getAddress() +
                                   ", Phone: " + passenger.getPhoneNumber());
            }
        }
    }
    
    public void updateIncome(int income) {
        int newTotal = revenue.getIncome() + income;
        revenue.setTotalIncome(newTotal);
        System.out.println("Total Income updated to: $" + newTotal);
    }

    public void updateExpenses(int expense) {
        int newTotal = revenue.getExpenses() + expense;
        revenue.setTotalExpenses(newTotal);
        System.out.println("Total Expenses updated to: $" + newTotal);
    }
      
    // Other methods...
    
}
