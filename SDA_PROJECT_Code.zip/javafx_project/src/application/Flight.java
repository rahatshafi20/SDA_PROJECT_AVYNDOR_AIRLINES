package application;

import java.time.LocalDateTime;
import java.util.*; 

public abstract class Flight {
    private int ID;
    private String arrivalDestination;
    private String departureDestination;
    private LocalDateTime arrivalTime; // Using LocalDateTime
    private LocalDateTime departureTime; // Added for better handling
    private String flightDuration; // Optional: this could also be calculated
    private int remainingSeats;
    private DB_Handler db;
    private static Set<Integer> flightIDs = new HashSet<>();

    // Constructor
    public Flight(int ID, String arrivalDestination, String departureDestination, LocalDateTime departureTime, LocalDateTime arrivalTime, int remainingSeats) 
    {
	  if (flightIDs.contains(ID)) {
	      throw new IllegalArgumentException("Flight ID " + ID + " is already in use. Please use a unique ID.");
	  }
	  if (departureTime.isAfter(arrivalTime)) {
	      throw new IllegalArgumentException("Departure time cannot be after arrival time.");
	  }
	  this.ID = ID;
	  flightIDs.add(ID);
	  this.arrivalDestination = arrivalDestination;
	  this.departureDestination = departureDestination;
	  this.departureTime = departureTime;
	  this.arrivalTime = arrivalTime;
	  this.remainingSeats = remainingSeats;
	  // Optional: Calculate the flight duration
	  this.flightDuration = calculateFlightDuration();
	  db = new DB_Handler();
	  db.add_Flight(this);
	}

    // Abstract Method
    public abstract int getCost();

    private String calculateFlightDuration() {
        if (departureTime != null && arrivalTime != null) {
            // Calculate the duration once
            java.time.Duration duration = java.time.Duration.between(departureTime, arrivalTime);
            
            long days = duration.toDaysPart();
            long hours = duration.toHoursPart();  // toHoursPart() for hours part
            long minutes = duration.toMinutesPart();
            
            return days + "D " + hours + "H " + minutes + "M ";
        }
        return "Unknown";
    }

    // Common Methods
    public String flightDetails() {
        return "Flight ID: " + ID +
               ", From: " + departureDestination +
               ", To: " + arrivalDestination +
               ", Departure: " + departureTime +
               ", Arrival: " + arrivalTime +
               ", Duration: " + flightDuration +
               ", Seats Left: " + remainingSeats;
    }

    public boolean bookFlight() {
        if (remainingSeats > 0) {
            remainingSeats--;
            return true;
        }
        return false;
    }

    // Getters and Setters
    public int getID() {
        return ID;
    }

    public String getArrivalDestination() {
        return arrivalDestination;
    }

    public String getDepartureDestination() {
        return departureDestination;
    }

    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalDateTime arrivalTime) {
        this.arrivalTime = arrivalTime;
        this.flightDuration = calculateFlightDuration(); // Update duration when times change
    }

    public LocalDateTime getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(LocalDateTime departureTime) {
        this.departureTime = departureTime;
        this.flightDuration = calculateFlightDuration(); // Update duration when times change
    }

    public String getFlightDuration() {
        return flightDuration;
    }

    public int getRemainingSeats() {
        return remainingSeats;
    }

    public void setRemainingSeats(int remainingSeats) {
        this.remainingSeats = remainingSeats;
    }
}

 class EconomyClass extends Flight {
    private static final int NORMAL_RATE = 150;

    public EconomyClass(int ID, String arrivalDestination, String departureDestination, 
                        LocalDateTime arrivalTime,  LocalDateTime  flightDuration, int remainingSeats) {
        super(ID, arrivalDestination, departureDestination, arrivalTime, flightDuration, remainingSeats);
    }

    @Override
    public int getCost() {
    	
        return NORMAL_RATE; 
    }
}

  class BusinessClass extends Flight {
	    private static final int PREMIUM_RATE = 300;

	    public BusinessClass(int ID, String arrivalDestination, String departureDestination, 
	    		LocalDateTime arrivalTime, LocalDateTime flightDuration, int remainingSeats) {
	        super(ID, arrivalDestination, departureDestination, arrivalTime, flightDuration, remainingSeats);
	    }

	    @Override
	    public int getCost() {
	    	
	        return PREMIUM_RATE;
	    }
	}
  
  class FirstClass extends Flight {
	    private static final int LUXURY_RATE = 700;

	    public FirstClass(int ID, String arrivalDestination, String departureDestination, 
	    		LocalDateTime arrivalTime, LocalDateTime flightDuration, int remainingSeats) {
	        super(ID, arrivalDestination, departureDestination, arrivalTime, flightDuration, remainingSeats);
	    }

	    @Override
	    public int getCost() {
	    	
	        return LUXURY_RATE;	    }
	}