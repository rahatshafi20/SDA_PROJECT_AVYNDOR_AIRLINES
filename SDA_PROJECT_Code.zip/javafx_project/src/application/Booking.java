package application;

import java.time.LocalDate;
import java.util.ArrayList;

public class Booking {
    private int ID;
    private Flight flightDetails;
    private Payment paymentDetails;
    private int price;
    public static ArrayList<Booking> bookingsList = new ArrayList<>();
    CancelTicket cancel;
	private Promotion promotion;
	private int Passenger_ID;
	private DB_Handler db;
    // Constructor
    public Booking(int ID, Flight flightDetails,Passenger passengerDetails ,Payment paymentDetails, Promotion promotion, int price) {
        this.ID = ID;
        this.flightDetails = flightDetails;
        this.paymentDetails = paymentDetails;
        this.setPromotion(promotion);
        this.price = price;
        this.Passenger_ID = passengerDetails.getID();
        db = new DB_Handler();
        db.add_Booking(this);
    }

    // Method to book a flight
    public static void bookFlight(Passenger passenger, Flight flight, String promoCode) {
        if (flight.getRemainingSeats() > 0) { // Check if seats are available
            int bookingID = bookingsList.size() + 1; // Generate a unique booking ID
            Payment payment = new Payment(flight.getCost()); // Initialize payment with the flight price
            Promotion promotion = null; // Optional promotion (set to null for now)

            // Check if promoCode is provided, and apply the promotion if valid
            if (promoCode != null && !promoCode.isEmpty()) {
                promotion = Promotion.getPromotion(promoCode); // Fetch promotion using the code
            }
            
            int price = flight.getCost();
            
            // Apply promotion if available
            if (promotion != null) {
                price = (int) promotion.applyPromotion(price); // Apply discount and update price
            }

            Booking booking = new Booking(bookingID, flight, passenger, payment, promotion, price);

            // Mark the flight as booked
            flight.bookFlight();

            // Add the booking to the list
            bookingsList.add(booking);

            System.out.println("Flight " + flight.getID() + " booked successfully for Passenger ID: " + passenger.getID());
        } else {
            System.out.println("No seats available for Flight " + flight.getID());
        }
    }


    // New Method: Display all bookings
    public static void displayAllBookings() {
        if (bookingsList.isEmpty()) {
            System.out.println("No bookings have been made yet.");
        } else {
            System.out.println("List of All Bookings:");
            for (Booking booking : bookingsList) {
                System.out.println("Booking ID: " + booking.getID() +
                                   ", Flight ID: " + booking.flightDetails.getID() +
                                   ", Price: $" + booking.price);
            }
        }
    }
    
    public static void displayBooking(Passenger passenger) {
        boolean found = false;
        for (Booking booking : bookingsList) {
            if (passenger.getID() == booking.getID()) {
                System.out.println("Booking for Passenger ID: " + passenger.getID());
                System.out.println(booking.flightDetails.flightDetails());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No bookings found for Passenger ID: " + passenger.getID());
        }
    }


    // Getters and setters...
    public int getID() {
        return ID;
    }

    public Flight getFlightDetails() {
        return flightDetails;
    }

    public static ArrayList<Booking> getBookingsList() {
        return bookingsList;
    }


    public void applyPromotion(Promotion promotion) {
        if (promotion != null && promotion.validatePromo()) {
            this.setPromotion(promotion);
            this.price = (int) promotion.applyPromotion(this.price);
        }
    }

    public void makePayment(int price) {
        // Logic for making payment
    	if(paymentDetails.paymentStatus(price)) {
            System.out.println("Payment completed successfully.");
    	}
    	
    }

    public static void cancelTicket(int id) {
        // Logic for canceling a ticket
    	//cancel.cancelStatus(id);
    	CancelTicket.cancelBooking(id);
    	
    }

	public Promotion getPromotion() {
		return promotion;
	}

	public void setPromotion(Promotion promotion) {
		this.promotion = promotion;
	}
	public int getPassengerID()
	{
		return Passenger_ID;
	}
	public int getPrice()
	{
		return price;
	}
}

