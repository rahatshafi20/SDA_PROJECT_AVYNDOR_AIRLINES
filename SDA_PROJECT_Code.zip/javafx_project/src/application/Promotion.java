package application;

import java.time.LocalDate;
import java.util.ArrayList;

public class Promotion {
    private String code;               
    private int percentDiscount;    
    private LocalDate startDate;     
    private LocalDate endDate;        
    private static ArrayList<Promotion> promotionsList = new ArrayList<>(); 

    // Constructor
    public Promotion(String code, int percentDiscount, LocalDate startDate, LocalDate endDate) {
        this.code = code;
        this.percentDiscount = percentDiscount;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Method to validate the promotion code
    public boolean validatePromo() {
        LocalDate today = LocalDate.now();
        return today.isAfter(startDate) && today.isBefore(endDate);
    }

    // Method to calculate the discounted price
    public float applyPromotion(float originalPrice) {
        if (!validatePromo()) {
            System.out.println("Promotion code " + code + " is invalid or expired.");
            return originalPrice;
        }
        float discountedPrice = originalPrice * (1 - percentDiscount/100.0f);
        System.out.println("Promotion applied! Original Price: $" + originalPrice + ", Discounted Price: $" + discountedPrice);
        return discountedPrice;
    }

    // Static method to add a new promotion
    public static void addPromotion(String code, int percentDiscount, LocalDate startDate, LocalDate endDate) {
        Promotion promo = new Promotion(code, percentDiscount, startDate, endDate);
        promotionsList.add(promo);
        System.out.println("Promotion " + code + " added successfully!");
    }

    // Static method to get a promotion by code
    public static Promotion getPromotion(String promoCode) {
        for (Promotion promo : promotionsList) {
            if (promo.getCode().equalsIgnoreCase(promoCode)) {
                return promo;
            }
        }
        System.out.println("Promotion code " + promoCode + " not found.");
        return null;
    }


    // Getters and setters
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getPercentDiscount() {
        return percentDiscount;
    }

    public void setPercentDiscount(int percentDiscount) {
        this.percentDiscount = percentDiscount;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}