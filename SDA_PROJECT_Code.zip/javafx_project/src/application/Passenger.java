package application;

import java.util.HashSet;
import java.util.Set;


public class Passenger {
	public static int id_setter = 0;
    private int ID;
    private String password;
    private String name;
    private String email;
    private String address;
    private String phoneNumber;
    private String userName;
    private DB_Handler db;
    
    private static Set<Integer> passengerIDs = new HashSet<>();
  
    
    // Constructor
    //null constructore
    public Passenger()
    {
    	
    	//nul and deosn nothigs
    	db = new DB_Handler();
        //adding passenger to database
    	
    }
    public Passenger(String password, String name, String email, String address, String phoneNumber, String Username) {
    	if (passengerIDs.contains(ID)) {
            throw new IllegalArgumentException("Passenger ID " + ID + " is already in use. Please use a unique ID.");
        }
        this.ID = ++id_setter;
        passengerIDs.add(ID);
        this.password = password;
        this.name = name;
        this.email = email;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.userName = Username;
        db = new DB_Handler();
        //adding passenger to database
        db.add_Passenger(this);
    }

    // Methods
    public void makeBooking(Flight flight,String promo) {
        if (flight.getRemainingSeats() > 0) {
            Booking.bookFlight(this, flight,promo); // Calls the static method from Booking class
        } else {
            System.out.println("No seats available for Flight ID: " + flight.getID());
        }
    }

    public void makeComplain(String complaintText) {
        // Logic for lodging a complaint
    	 Complain.enterComplaint(this.ID, complaintText);
    	Complain.viewComplaints(this.ID);
    }

    public void viewBooking() {
    	  Booking.displayBooking(this);
    }

    // Getters and setters
    public int getID() {
        return ID;
    }

    public String getPassword() {
    	return password;
    }
    
    public String getName() {
    	return name;
    }
    
    public String getEmail() {
    	return email;
    }
    
    public String getAddress() {
    	return address;
    }
    
    public String getPhoneNumber() {
    	return phoneNumber;
    }
    public String getUserName() {
    	return userName;
    }
    
    
    public void setID(int ID) {
        this.ID = ID;
    }

	public void setUserName(String string) {
		userName = string;
	}

	public void setPassword(String string) {
		password = string;
		
	}

	public void setEmail(String string) {
		email = string;
	}

	public void setAddress(String string) {
		// TODO Auto-generated method stub
		address = string;
	}

	public void setPhoneNumber(String string) {
		phoneNumber = string;
		
	}

	public void setName(String string) {
		name = string;
		
	}

    // Other getters and setters...
}

