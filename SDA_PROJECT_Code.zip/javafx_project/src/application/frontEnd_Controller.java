package application;
import java.io.IOException;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Node;
public class frontEnd_Controller {
	private Stage stage;
	private Scene scene;
	private Parent root;

    @FXML
    private Button button1_signup;

    @FXML
    void signUp(ActionEvent event) throws IOException {
    	System.out.println("Enterred");
    	SwitchToScene2(event);
    }
    
    
    void SwitchToScene1 (ActionEvent event) throws IOException {	//create account page
    	Parent root = FXMLLoader.load(getClass().getResource("signup.fxml"));
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.show();
    }
    void SwitchToScene2 (ActionEvent event) throws IOException {	//Login page
    	Parent root = FXMLLoader.load(getClass().getResource("pageone.fxml"));
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.show();
    }
    void SwitchToScene3 (ActionEvent event) throws IOException {	//main page page
    	Parent root = FXMLLoader.load(getClass().getResource("mainscreen.fxml"));
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.show();
    }

}
