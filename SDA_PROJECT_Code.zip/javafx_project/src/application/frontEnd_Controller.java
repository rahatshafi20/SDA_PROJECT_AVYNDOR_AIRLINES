package application;
import java.io.IOException;
import javafx.scene.control.TextField;


import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Node;
public class frontEnd_Controller {
	private Stage stage;
	private Scene scene;
	private Parent root;
	private AirlineTicketManagmentSystem ATMS;

    @FXML
    private Button button1_signup;
 
    //scene switchings
    void SwitchToScene1 (ActionEvent event) throws IOException {	//create account page
    	root = FXMLLoader.load(getClass().getResource("signup.fxml"));
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.setScene(scene);
    	stage.show();
    }
    void SwitchToScene2 (ActionEvent event) throws IOException {	//Login page
    	root = FXMLLoader.load(getClass().getResource("pageone.fxml"));
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.setScene(scene);
    	stage.show();
    }
    void SwitchToScene3 (ActionEvent event) throws IOException {	//main page page
    	root = FXMLLoader.load(getClass().getResource("mainscreen.fxml"));
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	//ScrollBar s = new ScrollBar(); 
    	ScrollPane sp = new ScrollPane();
    	sp.setContent(root);
    	scene = new Scene(sp, 950, 650);
    	//scene = new Scene(root);
    	stage.setScene(scene);
    	stage.show();
    }
    //sign up page
    @FXML
    private TextField email;

    @FXML
    private TextField name1;

    @FXML
    private TextField number;

    @FXML
    private PasswordField password;

    @FXML
    private  TextField userName;
    @FXML
    private TextField address;
    @FXML
    void signUp(ActionEvent event) throws IOException {
    	//System.out.println("came here");
    	ATMS = new AirlineTicketManagmentSystem();
    	Passenger p = new Passenger(password.getText(), name1.getText(), email.getText(), address.getText(), number.getText(), userName.getText());
    	SwitchToScene2(event);	
    }
    @FXML
    void button_signin_pressed(ActionEvent event) throws IOException {
    	SwitchToScene2(event);
    }
    //login page
    @FXML
    private Button login_button;
    @FXML
    private PasswordField pass;

    @FXML
    private TextField uname;

    @FXML
    void login(ActionEvent event) throws IOException {
    	if (ATMS == null)
    		ATMS = new AirlineTicketManagmentSystem();
    	if(ATMS.login(uname.getText(), pass.getText()))
    	{
    		SwitchToScene3(event);
    	}

    }
    
    
}
