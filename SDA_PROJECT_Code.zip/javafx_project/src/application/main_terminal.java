package application;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.util.Scanner;
public class main_terminal {
	//public static void main(String[] args) {
       /* // Create some concrete flights (e.g., EconomyClass)
        Flight flight1 = new EconomyClass(101, "Los Angeles", "New York", 
                                          LocalDateTime.of(2024, 11, 21, 10, 0), 
                                          LocalDateTime.of(2024, 11, 21, 15, 0), 
                                          3);
        
        Flight flight2 = new BusinessClass(102, "Chicago", "Miami", 
                                           LocalDateTime.of(2024, 11, 21, 14, 0), 
                                           LocalDateTime.of(2024, 11, 21, 17, 0), 
                                            2); // No seats available
	        
        AirlineTicketManagmentSystem ATM = new AirlineTicketManagmentSystem();
	        
        // Create passengers
        Passenger passenger1 = new Passenger(1, "password123", "John Doe", "john@example.com", "123 Main St", "555-1234");
        Passenger passenger2 = new Passenger(2, "password123", "Jane Doe", "jane@example.com", "456 Elm St", "555-5678");
        Passenger passenger3 = new Passenger(3, "password123", "Jake Smith", "jake@example.com", "789 Oak St", "555-9876");
        String promoCode = "SUMMER10"; 
        String promoCode2="\0"; 
	    // Add a promoton
	    Promotion.addPromotion("SUMMER10", 10, LocalDate.now().minusDays(1), LocalDate.now().plusDays(30)); // 10% discount
	      
	    ATM.createPassenger(passenger1);
	    ATM.createPassenger(passenger2);
	    ATM.createPassenger(passenger3);
	    // Passenger makes bookings
	    passenger1.makeBooking(flight1,promoCode); // Booking a flight with available seats
	    passenger2.makeBooking(flight1,promoCode2); // Booking a flight with available seats
	    passenger3.makeBooking(flight1,promoCode2); // Booking a flight with available seats (last seat)
	      
	    passenger1.viewBooking();
	        // Complaint about lost luggage
	       // passenger3.makeComplain("Lost Luggage");
	        
	        // Try booking a flight with no seats available
	       // passenger1.makeBooking(flight2); // Should display "No seats available"

	        // Display all bookings
	        //Booking.displayAllBookings();

	       // Promotion.addPromotion("SUMMER20", 2, LocalDate.of(2024, 6, 1), LocalDate.of(2024, 8, 31));
	       // Promotion.addPromotion("WINTER15", 15, LocalDate.of(2024, 12, 1), LocalDate.of(2025, 2, 28));
	        
	        // Cancel a booking (using passenger ID)
	      //  Booking.cancelTicket(2); // Cancel passenger2's ticket
	       // Booking.displayAllBookings(); // Display bookings after cancellation
	     //  ATM.passengerView();*/
		//import java.time.LocalDateTime;
		//import java.time.LocalDate;
		//import java.util.Scanner;

		//public class Main {
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        AirlineTicketManagmentSystem ATM = new AirlineTicketManagmentSystem();

		        System.out.println("Enter the type of flight class to create (EconomyClass/BusinessClass): ");
		        String flightClass = scanner.nextLine();

		        System.out.println("Enter flight ID: ");
		        int flightId = scanner.nextInt();
		        scanner.nextLine(); // Consume newline

		        System.out.println("Enter departure city: ");
		        String departureCity = scanner.nextLine();

		        System.out.println("Enter arrival city: ");
		        String arrivalCity = scanner.nextLine();

		        System.out.println("Enter departure date and time (YYYY-MM-DDTHH:MM): ");
		        String departureDateTime = scanner.nextLine();
		        LocalDateTime departureTime = LocalDateTime.parse(departureDateTime);

		        System.out.println("Enter arrival date and time (YYYY-MM-DDTHH:MM): ");
		        String arrivalDateTime = scanner.nextLine();
		        LocalDateTime arrivalTime = LocalDateTime.parse(arrivalDateTime);

		        System.out.println("Enter number of seats available: ");
		        int seatsAvailable = scanner.nextInt();
		        scanner.nextLine(); // Consume newline

		        Flight flight;
		        if (flightClass.equalsIgnoreCase("EconomyClass")) {
		            flight = new EconomyClass(flightId, departureCity, arrivalCity, departureTime, arrivalTime, seatsAvailable);
		        } else if (flightClass.equalsIgnoreCase("BusinessClass")) {
		            flight = new BusinessClass(flightId, departureCity, arrivalCity, departureTime, arrivalTime, seatsAvailable);
		        } else {
		            System.out.println("Invalid flight class.");
		            return;
		        }

		        System.out.println("Enter passenger details: ");
		        System.out.println("Enter passenger ID: ");
		        int passengerId = scanner.nextInt();
		        scanner.nextLine(); // Consume newline

		        System.out.println("Enter password: ");
		        String password = scanner.nextLine();

		        System.out.println("Enter name: ");
		        String name = scanner.nextLine();

		        System.out.println("Enter email: ");
		        String email = scanner.nextLine();

		        System.out.println("Enter address: ");
		        String address = scanner.nextLine();

		        System.out.println("Enter phone number: ");
		        String phoneNumber = scanner.nextLine();

		        Passenger passenger = new Passenger(passengerId, password, name, email, address, phoneNumber);

		        System.out.println("Enter promotion code (or press Enter if none): ");
		        String promoCode = scanner.nextLine();

		        ATM.createPassenger(passenger);
		        Promotion.addPromotion("SUMMER10", 10, LocalDate.now().minusDays(1), LocalDate.now().plusDays(30)); // 10% discount

		        passenger.makeBooking(flight, promoCode.isEmpty() ? "\0" : promoCode); // Booking a flight with or without promo code

		        passenger.viewBooking();

		        // Further actions can be added here as needed

		        scanner.close();
		    }
		

	        
	    }
	


