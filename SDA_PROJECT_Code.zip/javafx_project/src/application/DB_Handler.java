package application;
import java.sql.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
public class DB_Handler {
	public void add_Passenger(Passenger p) {
		try
		{
		String driverClassName =  "oracle.jdbc.OracleDriver";
		String URL = "jdbc:oracle:thin:@localhost:1521:xe";
		String UserName= "system";
		String Pass= "abc12345";
		String check_table_query = "Select count(*) FROM Passengers";
		String query = "CREATE TABLE Passengers (ID NUMBER(5) PRIMARY KEY, NAME VARCHAR2(30), PASSWORD VARCHAR(30), EMAIL VARCHAR2(30), ADDRESS VARCHAR2(30), PHONENUMBER VARCHAR2(13))";
		Class.forName(driverClassName);
		Connection Con = DriverManager.getConnection(URL, UserName, Pass);
		Statement st = Con.createStatement();
		int entries = st.executeUpdate(check_table_query);
		if (entries > 0)	//Checking if the table exists
		{
			System.out.println("Table already exists");
		}
		else 	//Creating a table
		{
			int count = st.executeUpdate(query);
			System.out.print(count);
		}
		System.out.println("Connected Successfully");
		
		/*System.out.println(p.getID());
		System.out.println(p.getName());
		System.out.println(p.getPassword());
		System.out.println(p.getEmail());
		System.out.println(p.getPhoneNumber());
		System.out.println(p.getUserName());*/
		//Now adding the guest in the table
		String add_guest_query = "INSERT INTO Passengers VALUES(?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = Con.prepareStatement(add_guest_query);
		statement.setInt(1, p.getID());
		statement.setString(2, p.getName());
		statement.setString(3, p.getPassword());
		statement.setString(4, p.getEmail());
		statement.setString(5, p.getAddress());
		statement.setString(6, p.getPhoneNumber());
		statement.setString(7, p.getUserName());
		entries = statement.executeUpdate();
		if (entries > 0)
			System.out.println("Passenger added successfully");
		else
			System.out.println("Error in adding passenger into database");
		Con.close();
		}
		
		catch(ClassNotFoundException e){
			System.out.println("Driver not loaded");
		}
		catch(SQLException e) {
			System.out.println("Connection not established");
            //System.out.println("Message: " + e.getMessage());
            //System.out.println("SQL State: " + e.getSQLState());
            System.out.println("Error Code: " + e.getErrorCode());
            //e.printStackTrace();
		}
		
	}
	//Loging in the passenger
	public boolean login_Passenger(String userName, String password) {
	    try {
	    	System.out.println("Came here");
	        String driverClassName = "oracle.jdbc.OracleDriver";
	        String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	        String UserName = "system";
	        String Pass = "abc12345";
	        String login_query = "SELECT COUNT(*) FROM Passengers WHERE USERNAME = ? AND PASSWORD = ?";

	        Class.forName(driverClassName);
	        Connection Con = DriverManager.getConnection(URL, UserName, Pass);

	        // Prepare the SQL statement
	        PreparedStatement statement = Con.prepareStatement(login_query);
	        statement.setString(1, userName);
	        statement.setString(2, password);

	        // Execute the query
	        ResultSet rs = statement.executeQuery();
	        rs.next(); // Move to the first (and only) result
	        int count = rs.getInt(1);

	        Con.close();

	        // Check if the passenger exists
	        if (count > 0) {
	            System.out.println("Login successful");
	            return true;
	        } else {
	            System.out.println("Invalid ID or password");
	            return false;
	        }
	    } catch (ClassNotFoundException e) {
	        System.out.println("Driver not loaded");
	        return false;
	    } catch (SQLException e) {
	        System.out.println("Connection not established");
	        System.out.println("Error Code: " + e.getErrorCode());
	        return false;
	    }
	}

	public ArrayList<Passenger> get_Passengers() {
        ArrayList<Passenger> passengers = new ArrayList<>();
        try {
            String driverClassName = "oracle.jdbc.OracleDriver";
            String URL = "jdbc:oracle:thin:@localhost:1521:xe";
            String UserName = "system";
            String Pass = "abc12345";
            String query = "SELECT * FROM Passengers";
            Class.forName(driverClassName);
            Connection Con = DriverManager.getConnection(URL, UserName, Pass);
            Statement st = Con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
            	Passenger.id_setter++;
                Passenger p = new Passenger();
                p.setID(rs.getInt("ID"));
                p.setUserName(rs.getString("USERNAME"));
                p.setName(rs.getString("NAME"));
                p.setPassword(rs.getString("PASSWORD"));
                p.setEmail(rs.getString("EMAIL"));
                p.setAddress(rs.getString("ADDRESS"));
                p.setPhoneNumber(rs.getString("PHONENUMBER"));
                passengers.add(p);
            }

            Con.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not loaded");
        } catch (SQLException e) {
            System.out.println("Connection not established");
            System.out.println("Error Code: " + e.getErrorCode());
        }
        return passengers;
    }
	public void add_Flight(Flight f) {
		try
		{
		String driverClassName =  "oracle.jdbc.OracleDriver";
		String URL = "jdbc:oracle:thin:@localhost:1521:xe";
		String UserName= "system";
		String Pass= "abc12345";
		String check_table_query = "Select count(*) FROM Flight";
		String query = "CREATE TABLE Flight (INT NUMBER primary key, Departure_Dest varchar(20), Arrival_Dest varchar(20), Departure_time TimeStamp, Arrival_time TimeStamp, flight_duration varchar(50), reamining_seats INT);";
		Class.forName(driverClassName);
		Connection Con = DriverManager.getConnection(URL, UserName, Pass);
		Statement st = Con.createStatement();
		int entries = st.executeUpdate(check_table_query);
		if (entries > 0)	//Checking if the table exists
		{
			System.out.println("Table already exists");
		}
		else 	//Creating a table
		{
			int count = st.executeUpdate(query);
			System.out.print(count);
		}
		System.out.println("Connected Successfully");
		
		//Now adding the guest in the table
		String add_guest_query = "INSERT INTO Flight VALUES(?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = Con.prepareStatement(add_guest_query);
		statement.setInt(1, f.getID());
		statement.setString(2, f.getDepartureDestination());
		statement.setString(3, f.getArrivalDestination());
		statement.setTimestamp(4, Timestamp.valueOf(f.getDepartureTime()));
		statement.setTimestamp(5, Timestamp.valueOf(f.getArrivalTime()));
		statement.setString(6, f.getFlightDuration());
		statement.setInt(7, f.getRemainingSeats());
		
		entries = statement.executeUpdate();
		if (entries > 0)
			System.out.println("Flight added successfully");
		else
			System.out.println("Error in adding Flight into database");
			
		Con.close();
		}
		
		catch(ClassNotFoundException e){
			System.out.println("Driver not loaded");
		}
		catch(SQLException e) {
			System.out.println("Connection not established");
		}
	}
	public void add_Booking(Booking b) {
		try
		{
		String driverClassName =  "oracle.jdbc.OracleDriver";
		String URL = "jdbc:oracle:thin:@localhost:1521:xe";
		String UserName= "system";
		String Pass= "abc12345";
		String check_table_query = "CREATE TABLE Booking (Booking_ID NUMBER PRIMARY KEY, Passenger_ID NUMBER, Payment_ID NUMBER, "
				+ "Promo_code VARCHAR2(10), Flight_ID NUMBER, Price_due NUMBER, "
				+ "CONSTRAINT fk_passenger FOREIGN KEY (Passenger_ID) REFERENCES Passengers (ID),"
				+ "CONSTRAINT fk_payment FOREIGN KEY (Payment_ID) REFERENCES Payment (ID),"
				+ "CONSTRAINT fk_promo FOREIGN KEY (Promo_code) REFERENCES Promotion (code),"
				+ "CONSTRAINT fk_flight FOREIGN KEY (Flight_ID) REFERENCES Flight (INT));";
		Class.forName(driverClassName);
		Connection Con = DriverManager.getConnection(URL, UserName, Pass);
		Statement st = Con.createStatement();
		int entries = st.executeUpdate(check_table_query);
		if (entries > 0)	//Checking if the table exists
		{
			System.out.println("Table already exists");
		}
		else 	//Creating a table
		{
			int count = st.executeUpdate(check_table_query);
			System.out.print(count);
		}
		System.out.println("Connected Successfully");
		
		//Now adding the guest in the table
		String add_guest_query = "INSERT INTO Booking VALUES(?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = Con.prepareStatement(add_guest_query);
		statement.setInt(1, b.getID());
		statement.setInt(2, b.getPassengerID());
		statement.setString(3, b.getPromotion().getCode());
		statement.setInt(4, b.getPrice());
		
		entries = statement.executeUpdate();
		if (entries > 0)
			System.out.println("Booking added successfully");
		else
			System.out.println("Error in adding Booking into database");
			
		Con.close();
		}
		
		catch(ClassNotFoundException e){
			System.out.println("Driver not loaded");
		}
		catch(SQLException e) {
			System.out.println("Connection not established");
		}
	}
	public void add_Payment(Payment p) {
		try
		{
		String driverClassName =  "oracle.jdbc.OracleDriver";
		String URL = "jdbc:oracle:thin:@localhost:1521:xe";
		String UserName= "system";
		String Pass= "abc12345";
		String check_table_query = "Select count(*) FROM Payment";
		String query = "CREATE TABLE Payment (ID NUMBER primary key, status char(1), amount_due INT, amount_paid INT);";
		Class.forName(driverClassName);
		Connection Con = DriverManager.getConnection(URL, UserName, Pass);
		Statement st = Con.createStatement();
		int entries = st.executeUpdate(check_table_query);
		if (entries > 0)	//Checking if the table exists
		{
			System.out.println("Table already exists");
		}
		else 	//Creating a table
		{
			int count = st.executeUpdate(query);
			System.out.print(count);
		}
		System.out.println("Connected Successfully");
		
		//Now adding the guest in the table
		String add_guest_query = "INSERT INTO Payment VALUES(?, ?, ?, ?)";
		PreparedStatement statement = Con.prepareStatement(add_guest_query);
		statement.setInt(1, Payment.id);
		statement.setBoolean(2, p.status);
		statement.setInt(3, p.amountDue);
		statement.setInt(4, p.amountPaid);
		entries = statement.executeUpdate();
		if (entries > 0)
			System.out.println("Payment added successfully");
		else
			System.out.println("Error in adding Booking into database");
			
		Con.close();
		}
		
		catch(ClassNotFoundException e){
			System.out.println("Driver not loaded");
		}
		catch(SQLException e) {
			System.out.println("Connection not established");
		}
	}
	public void add_Promotion(Promotion promo) {
		try
		{
		String driverClassName =  "oracle.jdbc.OracleDriver";
		String URL = "jdbc:oracle:thin:@localhost:1521:xe";
		String UserName= "system";
		String Pass= "abc12345";
		String check_table_query = "Select count(*) FROM Promotion";
		String query = "CREATE TABLE Promotion (code varchar(10) primary key, percent_discount INT, start_date DATE, end_date DATE);";
		Class.forName(driverClassName);
		Connection Con = DriverManager.getConnection(URL, UserName, Pass);
		Statement st = Con.createStatement();
		int entries = st.executeUpdate(check_table_query);
		if (entries > 0)	//Checking if the table exists
		{
			System.out.println("Table already exists");
		}
		else 	//Creating a table
		{
			int count = st.executeUpdate(query);
			System.out.print(count);
		}
		System.out.println("Connected Successfully");
		
		//Now adding the guest in the table
		String add_guest_query = "INSERT INTO Promotion VALUES(?, ?, ?, ?)";
		PreparedStatement statement = Con.prepareStatement(add_guest_query);
		statement.setString(1, promo.getCode());
		statement.setInt(2, promo.getPercentDiscount());
		statement.setDate(3, Date.valueOf(promo.getStartDate()));
		statement.setDate(4, Date.valueOf(promo.getEndDate()));
		entries = statement.executeUpdate();
		if (entries > 0)
			System.out.println("Payment added successfully");
		else
			System.out.println("Error in adding Booking into database");
			
		Con.close();
		}
		
		catch(ClassNotFoundException e){
			System.out.println("Driver not loaded");
		}
		catch(SQLException e) {
			System.out.println("Connection not established");
		}
	}
}