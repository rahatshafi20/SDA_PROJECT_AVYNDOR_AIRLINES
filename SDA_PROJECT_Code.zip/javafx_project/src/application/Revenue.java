package application;

public class Revenue {
    private int totalIncome;
    private int totalExpenses;
    private int totalProfit;

    public int getProfit() {
        return totalIncome - totalExpenses;
    }

    public int getIncome() {
        return totalIncome;
    }

    public int getExpenses() {
        return totalExpenses;
    }

    // Getters and setters
    public void setTotalIncome(int totalIncome) {
        this.totalIncome = totalIncome;
    }

    public int getTotalExpenses() {
        return totalExpenses;
    }

    public void setTotalExpenses(int totalExpenses) {
        this.totalExpenses = totalExpenses;
    }

    public int getTotalProfit() {
        return totalProfit;
    }

    public void setTotalProfit(int totalProfit) {
        this.totalProfit = totalProfit;
    }
}
