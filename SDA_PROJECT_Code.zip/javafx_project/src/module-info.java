module javafx_project {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
	requires java.sql;
	
	requires de.jensd.fx.glyphs.fontawesome;
	requires javafx.fxml;
	requires javafx.graphics;
	requires com.gluonhq.charm.glisten;
    requires com.gluonhq.attach.util;
}

